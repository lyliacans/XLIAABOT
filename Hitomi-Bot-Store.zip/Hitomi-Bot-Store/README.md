</p>
<p align="center">
<a href="#"><img title="HITOMI BOT" src="https://img.shields.io/badge/HITOMI BOT BY CHRISTIAN ID-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

</div>


---

## Bugs and Tester
* Jika kamu menemukan bug jangan lupa buka Issues
* Info Lebih Lanjut, Chat [owner-hitomi](https://wa.me/6285921165857)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip) (for sticker command)

# Instalasi
## Heroku Buildpack
```bash
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```
## For Termux
```ts
termux-setup-storage
apt update && apt upgrade
pkg install nodejs git ffmpeg libwebp imagemagick
cd /sdcard
cp -r Hitomi-Bot-Store /$HOME
cd Hitomi-Bot-Store
pkg install yarn
yarn
npm start
```

## ```HOW TO DEPLOY```

[`Click Here For Tutorial`](https://youtu.be/_CP2_1Yqauo)<br>

----------

<p align="center">
  <a href="https://youtu.be/_CP2_1Yqauo"><img src="https://telegra.ph/file/042309a3aee80be40c474.jpg" />
</p>

## Donate
- [Dana](https://i.ibb.co/f2h3MDQ/Qris.jpg)
- [Gopay](https://i.ibb.co/f2h3MDQ/Qris.jpg)
- [Ovo](https://i.ibb.co/f2h3MDQ/Qris.jpg)

# Youtube
- https://youtube.com/c/ChristianID99

# Thanks to
- rtwone / Irfan
- Christian ID
- Nc Tech